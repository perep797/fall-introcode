score = 28
#this is a comment
name = "pau"

print(name)

name = "lol"

print(name)

count = 0 
print(count)
count = count + 1
print(count)

names = ["hi", "lol2", "lol3", "lol4"]
NumberofNames = len(names)
print(NumberofNames)
print(names[0])

for student in names:
    print (student)