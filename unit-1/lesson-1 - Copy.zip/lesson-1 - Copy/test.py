x = 5
if x > 5:
    print("Greater than five!!")
else:
    print("Less than five!!!")
