
i = 0
while i < 13:
    print( i )
    i = i + 2
